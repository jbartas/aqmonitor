import { Component } from '@angular/core';
import { MapareaComponent } from './maparea/maparea.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Air Quality Monitor';

  newLatitude: Number = 0;
  newLongitude: Number = 0;

  onLocationChange(location: any): void  {
    console.log( "AppComponent.onLocationChange" + location );
    this.newLatitude = location.latitude;
    this.newLongitude = location.longitude;
  }

}

